<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body{
  margin: 0;
  padding: 0;
  background: linear-gradient(120deg,#2980b9, #8e44ad);
  height: 100vh;
  overflow: hidden;
  font-family: Arial, Helvetica, sans-serif;
}

* {box-sizing: border-box;}

.container {
  border-radius: 5px;
  padding: 20px;
}

 .h1 {
  color: white;
  text-align: center;
  font-family: times-new-roman;
  font-size: 40px;
 }

 .box {
  border: 3px solid;
  padding: 7px;
  border-image: linear-gradient(45deg,white,black) 1;
}

.box2 {
  border: 5px solid;
  border-spacing: 4px;
  border-image: linear-gradient(45deg,red,blue) 1;
}

table {
  width: 500px;
  border-collapse: collapse;
  overflow: hidden;
  box-shadow: 0 0 20px rgba(0,0,0,0.1);
}

th,
td {
  padding: 15px;
  background-color: rgba(255,255,255,0.2);
  color: #fff;
}
 
</style>
</head>
<body>
  <br>
  <div class="box2">
  <h1 class="h1">Home</h1>
</div>
<br>
<h3 style ="color:white;font-family:times-new-roman; font-size:30px;">
<marquee>ASSIST U ---> We Stand By You</marquee>

<center>
  <img src="assist u white.jpg" width="180" height="180">
<br>
<div class="container">
  <table>
<th><a href="complaintpage.php"
    style="color:white; font-size:30px; float:center; text-decoration: none;">   New Complaint   </a></th>
  </table>
<table>
  <th>
  <a href="recomplaint.php" style="color:white; font-size:30px; float:center; text-decoration: none;"> Re-complaint </a>
</th></table>
<table>
  <th>
  <a href="displayemp.php" style="color:white; font-size:30px; float:center; text-decoration: none;"> Display all complaint records </a>
</th></table>
</div>
<br>
<center>
<style>
.simple-shadow{
  text-shadow: 1px 2px 2px red;
}
</style>
<p class="simple-shadow"><a href="login.php" style="color:white; font-size:30px;">LOG OUT</a></center><br>


</center>
</form>

</body>
</html>