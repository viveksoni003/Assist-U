<?php
$servername = "localhost";
$user = "root";
$password = "";
$dbname = "assist u";
$conn = mysqli_connect($servername,$user,$password,$dbname);
if($conn)
{
    //echo "Connection Successful!";
}
else
{
    echo "Connection Failed!".mysqli_connect_error();
}

error_reporting(0);
if($_POST['submit'])
{
    session_start();
    $us = $_SESSION['username'];

    $au = $_POST['au'];
    $against = $_POST['against'];
    $complaint = $_POST['complaint'];
    $reid = $_POST['reid'];
    $query = "INSERT INTO complaint VALUES('$us','$au','$against','$complaint','','re','$reid', 'sent')";
    $data = mysqli_query($conn,$query);

    if($data)
    {
        echo '<script type="text/javascript">
       window.onload = function () { alert("Your complaint was registered successfully!"); } 
       </script>';
    }
    else
    {
        echo '<script type="text/javascript">
       window.onload = function () { alert("Oops! Something went wrong!"); } 
       </script>';
    }
}

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
	body{
  margin: 0;
  padding: 0;
  background: linear-gradient(120deg,#2980b9, #8e44ad);
  height: 100vh;
  overflow: hidden;
  font-family: Arial, Helvetica, sans-serif;
}
input[type=text], select, textarea {
width: 100%;
padding: 12px;
border: 1px solid #ccc;
border-radius: 4px;
box-sizing: border-box;
margin-top: 6px;
margin-bottom: 16px;
resize: vertical;
}
input[type=submit] {
background-color: blue;
color: white;
padding: 12px 20px;
border: none;
border-radius: 4px;
cursor: pointer;
}
input[type=submit]:hover {
background-color: purple;
}
.container {
border-radius: 5px;
padding: 20px;
color: white;
}

.h1 {
text-align:center;
color:white;
}

.p {
    text-align: center;
    color: white;
}
</style>
</head>

<body>
<h1 class="h1">Re-Complaint Page</h1>

<div class="container">
<form action="#" method="POST">

<label for="au">Select Authorized User:</label>

<select name="au" id="au">
  <option value="A">A</option>
  <option value="B">B</option>
  <option value="C">C</option>
  <option value="D">D</option>
</select>

<label for="against">Complaint Against</label>
<input type="text" id="against" name="against" placeholder="Against user..">

<label for="complaint">Complaint</label>
<textarea id="complaint" name="complaint" placeholder="Write your complaint.." style="height:90px"></textarea>

<label for="reid">Complaint-Id of previous complaint</label>
<input type="text" id="reid" name="reid" placeholder="complaint-id">
<p> If didn't share this complaint previously then please go to the 'New Complaint' page </p>

<div class="container">
<center><input type="submit" name="submit" class="submit"></center>
</div>
 <center>
        <style>
.simple-shadow{
  text-shadow: 1px 2px 2px red;
}
</style>
<p class="simple-shadow"><a href="emphomepage.php" style="color:white; font-size:30px;">HOME</a></center><br>
        <style>
.simple-shadow{
  text-shadow: 1px 2px 2px red;
}
</style><center>
<p class="simple-shadow"><a href="login.php" style="color:white; font-size:25px;">LOG OUT</a></center>
    
<br><br>
    </center>
</body>
</html>