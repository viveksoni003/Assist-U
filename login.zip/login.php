<?php
include("connection.php");

if(!empty($_POST['login']))
{
  $username = $_POST['user'];
  $password = $_POST['pass'];
  $radio = $_POST['radio'];
  $query = "SELECT * FROM register where username='$username' and password = '$password'";
  $result = mysqli_query($conn,$query);
  $count=mysqli_num_rows($result);
  if($count>0)
  {
    if($radio == 'authorized')
    {
      header('Location:auhomepage.php');
    }
    else
    {
      header('Location:emphomepage.php');
    }
  }
  else
  {
    echo '<script type="text/javascript">
       window.onload = function () { alert("You are not registered!"); } 
       </script>';
  }
}
  
session_start();
$_SESSION['username']=$username;
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login Form</title>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@700&family=Poppins:wght@400;500;600&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}

body{
  margin: 0;
  padding: 0;
  background: linear-gradient(120deg,#2980b9, #8e44ad);
  height: 100vh;
  overflow: hidden;
}

.center{
  width: 400px;
  position: relative;
  border-color: white;
  bor
  padding: 3px;
  background: white;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  border-radius: 20px;
  box-shadow: 10px 10px 15px rgba(0,0,0,0.05);
}
.center h1{
  text-align: center;
  padding: 20px 0;
  border-bottom: 1px solid silver;
}
.center form{
  padding: 0 40px;
  box-sizing: border-box;
}
form .user{
  position: relative;
  border-bottom: 2px solid #adadad;
  margin: 30px 0;
}

form .pass{
  position: relative;
  border-bottom: 2px solid #adadad;
  margin: 30px 0;
}
.user input{
  width: 100%;
  padding: 0 5px;
  height: 40px;
  font-size: 16px;
  border: none;
  background: none;
  outline: none;
}

.pass input{
  width: 100%;
  padding: 0 5px;
  height: 40px;
  font-size: 16px;
  border: none;
  background: none;
  outline: none;
}



.user label{
  position: absolute;
  top: 50%;
  left: 5px;
  color: #adadad;
  transform: translateY(-50%);
  font-size: 16px;
  pointer-events: none;
  transition: .5s;
}

.pass label{
  position: absolute;
  top: 50%;
  left: 5px;
  color: #adadad;
  transform: translateY(-50%);
  font-size: 16px;
  pointer-events: none;
  transition: .5s;
}


.radibutton label{
 position: absolute;
  
}
.user span::before{
  content: '';
  position: absolute;
  top: 40px;
  left: 0;
  width: 0%;
  height: 2px;
  background: #2691d9;
  transition: .5s;
}

.pass span::before{
  content: '';
  position: absolute;
  top: 40px;
  left: 0;
  width: 0%;
  height: 2px;
  background: #2691d9;
  transition: .5s;
}

.user input:focus ~ label,
.user input:valid ~ label{
  top: -5px;
  color: #2691d9;
}
.user input:focus ~ span::before,
.user input:valid ~ span::before{
  width: 100%;
}

.pass input:focus ~ label,
.pass input:valid ~ label{
  top: -5px;
  color: #2691d9;
}
.pass input:focus ~ span::before,
.pass input:valid ~ span::before{
  width: 100%;
}

input[type="submit"]{
  width: 100%;
  height: 50px;
  border: 1px solid;
  background: #2691d9;
  border-radius: 25px;
  font-size: 18px;
  color: #e9f4fb;
  font-weight: 700;
  cursor: pointer;
  outline: none;
}
input[type="submit"]:hover{
  border-color: #2691d9;
  transition: .5s;
  background: purple;
}

.box {
  border: 10px solid;
  border-image: linear-gradient(45deg,red,blue) 10;
}
</style>
  </head>
  <body>
    <center><img src="assist u white.jpg" width="130" height="130"></center>
    <div class="center">
      <div class="box">
      <h1>Login</h1>
      <form method="post">
        <div class="radiobutton" name="radiobutton">
          <center>
            <br>

         <input type="radio" id="AU" name="radio" value="authorized">
          <label for="AU">Authorized User</label><br>

          <input type="radio" id="emp" name="radio" value="employee">
          <label for="emp">Employee</label>
          <br>

        </center>
        </div>

        <div class="user" >
          <input type="text" name="user">
          <span></span>
          <label>Username</label>
        </div>
        <div class="pass">
          <input type="password"  name="pass">
          <span></span>
          <label>Password</label>
        </div>
        <input type="submit" value="Login" name="login"><br><br>
        
        <a href="registeration.php"><center><p>Not a user? Get registered!</p><br></center><br></a>
      </form>
    </div>
  </div>
  </body>
</html>
