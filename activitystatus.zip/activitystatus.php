<?php
include("connection.php");

$query = "SELECT * FROM complaint";
$result = mysqli_query($conn,$query);

//error_reporting(0);

if(isset($_REQUEST["submit"])) 
{
    $status = $_REQUEST['status'];
    $id = $_REQUEST['id'];
    $query1 = "UPDATE complaint SET status = '$status' WHERE id ='$id'";
    $data = mysqli_query($conn,$query1);

    if($data)
        {
            echo '<script type="text/javascript">
            window.onload = function () { alert("Activity Status Changed!"); } 
            </script>';
        }
        else
        {
            echo '<script type="text/javascript">
            window.onload = function () { alert("Oops! Something went wrong!"); } 
            </script>';
        }
    }

?>

<!DOCTYPE html>
<html>
    <head>
        <title>
            setstatusofcomplaints
        </title>
        <style>
            body{

                margin-top: 0px;
                background: linear-gradient(to left,#8e44ad,#2980b9 )
            
            }
            div{
                
                text-align-last: center;
            }
            .topnav {
                background-color: rgb(184, 24, 224);
                overflow: hidden;
              }
              
              .topnav a {
                margin-left: 0px;
                    float: left;
                color: #f2f2f2;
                text-align: center;
                padding: 14px 16px;
                text-decoration: none;
                font-size: 17px;
              }
              
              /* Change the color of links on hover */
              .topnav a:hover {
                background-color: #ddd;
                color: pink;
              }
              
              /* Add a color to the active/current link */
              .topnav a.active {
                background-color: #7604aa;
                color: white;
              }
            .form{
                margin-top: 50px;
                margin-left: 40%;
            }
            input{
                
                width: 250px;
                padding:5px;
            }
            label{
                color:aliceblue;
            }
            h1{
                color:aliceblue;
            }
            * {
                margin: 0px;
                padding: 0;
                font-family: Arial, Helvetica, sans-serif;
            
            }
            
            
            .heading {
                display: flex;
                background-color: #232f3e;
                box-shadow: 0px 1px 2px #232f3e;
            
            }
            h1 {
                color: white;
                font-weight: bold;
                
                background: transparent;
                padding: 7px;
                
            }
            
            table {
                width: 500px;
                border-collapse: collapse;
                overflow: hidden;
                box-shadow: 0 0 20px rgba(0,0,0,0.1);

            }
            th, td {
                padding: 20px;
                background-color: rgba(255,255,255,0.2);
                color: #fff;
            }
            .box{
                margin-top: 0px;
                width: 400px;
                padding:20px;
                background:#f9f9f9;
                border:2px solid #333;
                    
            }
            .box label{
                color:#333;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }
            
            input[type="submit"]{
                width: 30%; 
                height: 50px;
                align-items: center;
                border: 1px solid; 
                background: #2691d9;
                border-radius: 25px;
                text-align: center;
                font-size: 18px;
                color: #e9f4fb;
                font-weight: 700;
                cursor: pointer;
                outline: none;
            }
            
            input[type="submit"]:hover{
                border-color: #2691d9;
                transition: .5s;
                background: purple;
            }
        </style>
    </head>
    <body>
        <div class="topnav">
            <a class="active" href="auhomepage.php">Home</a>
          </div>
        <center>
            <h1>Details of all complaints</h1> 
        
        <div>
            <table>
                <tr>
                    <th>Username</th>
                    <th>Complaint Id</th>
                    <th>Authorized User</th>
                    <th>Against User</th>
                    <th>Complaint</th>
                    <th>Status</th>
                </tr>
            <?php
        while($rows=mysqli_fetch_assoc($result))
        {
        ?>  

        <tr>
            <td><?php echo $rows['username']; ?></td>
            <td><?php echo $rows['id']; ?></td>
            <td><?php echo $rows['au']; ?></td>
            <td><?php echo $rows['against']; ?></td>
            <td><?php echo $rows['comp']; ?></td>
            <td><?php echo $rows['status']; ?></td>

        <?php
        }
        ?>
            </table>
        </div>
        
        <br><br>
        <div class="box">
            <form>
                <label>Complaint Id:</label>
                <input type="text" id="id" name="id"><br><br>
                <label>Set Status: </label>
                <select id="status" name="status">
                    <option value="sent">Sent</option>
                    <option value="read">Read</option>
                    <option value="resolved">Resolved</option>
                    
                  </select>
                  <br><Br>
                  <input type="submit" value="submit" name="submit"><br><br>
            </form>
        </div>
        <h2>
        <style>
.simple-shadow{
  text-shadow: 1px 2px 2px red;
}
</style>
        <style>
.simple-shadow{
  text-shadow: 1px 2px 2px red;
}
</style><center>
<p class="simple-shadow"><a href="login.php" style="color:white; font-size:25px;">LOG OUT</a></center>

    
<br><br>
        
    </body>
</html>