<?php include("newconn.php"); ?>

<!DOCTYPE html>
<html>
    <head>
        <title>
            registration for Student
        </title>
        <link rel="stylesheet" href="registration.css">
    </head>
    <body>
        <div class="topnav">
            <a class="active" href="#home">Home</a>
            <a href="#scholarshps">scholarships</a>
            <a href="#Examinfo">Exam info</a>
            <a href="#about">About us</a>
            <a href="login.html">Login</a>
        </div>
        <div class="registration"><center>
            <form>
            <label>Enrollment no.</label><br>
            <input type="text"><br>
            <label>Student name</label><br>
            <input type="text"><br>
            <label>password</label><br>
            <input type="text"><br>
            <label>mobile no.</label><br>
            <input type="text"><br>
            <label>Email id</label><br>
            <input type="text"><br><br><br><br>
        </form>
        </center>
    </div>
    <center>
    <tr>
                    <td height="60" colspan="2"><input
                        type="submit" name="submit"
                        value="Register" class="button">
                    </td>
                </tr>
            </center>
    </body>
</html>
<?php
if($_POST['submit']) 
{
    $enrollment = $_POST['enrollment id'];
    $studentname = $_POST['student name'];
    $email = $_POST['password'];
    $mob = $_POST['mob no'];
    $pwd = $_POST['email id'];

    $query = "INSERT INTO scholarship VALUES('$enrollment id','$student name','$password','$mob no','$email id')";
    $data = mysqli_query($conn,$query);

    if($data)
        {
            echo '<script type="text/javascript">
            window.onload = function () { alert("You are registered successfully!"); }
            </script>';
        }
        else
        {
           echo '<script type="text/javascript">
            window.onload = function () { alert("Oops! Something went wrong"); }
            </script>';
        }
    }
?>