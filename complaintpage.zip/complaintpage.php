<?php

$servername = "localhost";
$user = "root";
$password = "";
$dbname = "assist u";

$conn =  mysqli_connect($servername,$user,$password,$dbname);

if($conn)
{
    //echo "Connection Success!";
}
else
{
    echo "Connection failed!".mysqli_connect_error();
}

error_reporting(0);

if($_POST['submit']) 
{
    session_start();
    $us = $_SESSION['username'];

    $au = $_POST['au'];
    $against = $_POST['against'];
    $complaint = $_POST['complaint'];
    $query = "INSERT INTO complaint VALUES('$us','$au','$against','$complaint', '', 'not', '0', 'sent')";
    $data = mysqli_query($conn,$query);

    if($data)
        {
            echo '<script type="text/javascript">
            window.onload = function () { alert("Your complaint was registered successfully!"); } 
            </script>';
        }
        else
        {
            echo '<script type="text/javascript">
            window.onload = function () { alert("Oops! Something went wrong!"); } 
            </script>';
        }
    }
?>


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
  margin: 0;
  padding: 0;
  background: linear-gradient(120deg,#2980b9, #8e44ad);
  height: 100vh;
  overflow: hidden;
  font-family: Arial, Helvetica, sans-serif;
}

* 
{
    box-sizing: border-box;
}

input[type=text], select, textarea 
{
width: 100%;
padding: 12px;
border: 1px solid #ccc;
border-radius: 4px;
box-sizing: border-box;
margin-top: 6px;
margin-bottom: 16px;
resize: vertical;
}

input[type=submit] 
{
background-color: blue;
color: white;
padding: 12px 20px;
border: none;
border-radius: 4px;
cursor: pointer;
}

input[type=submit]:hover 
{
background-color: purple;
}

.container 
{
border-radius: 5px;
padding: 20px;
color:white;
}

.h1 {
    color:white;
    text-align:center;
}
</style>
</head>
<body>
<h1 class="h1">New Complaint Page</h1>

<div class="container">
<form action="#" method="POST">

<label for="au">Select Authorized User:</label>

<select name="au" id="au">
  <option value="A">A</option>
  <option value="B">B</option>
  <option value="C">C</option>
  <option value="D">D</option>
</select>

<label for="against">Complaint Againt</label>
<input type="text" id="against" name="against" placeholder="against user.">

<label for="complaint">Complaint</label>
<textarea id="complaint" name="complaint" placeholder="Write your complaint in 20 word.." style="height:90px"></textarea>

<div class="container">
<center><input type="submit" value="submit" class="submit" name="submit"></center>
</div>
<br><br>
    <center>
        <style>
.simple-shadow{
  text-shadow: 1px 2px 2px red;
}
</style>
<p class="simple-shadow"><a href="emphomepage.php" style="color:white; font-size:30px;">HOME</a></center><br>
        <style>
.simple-shadow{
  text-shadow: 1px 2px 2px red;
}
</style><center>
<p class="simple-shadow"><a href="login.php" style="color:white; font-size:25px;">LOG OUT</a></center>
    
<br><br>
    </center>
    
<br><br>
</form>
</body>
</html>