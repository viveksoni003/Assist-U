<?php
include("connection.php");

$query = "SELECT * FROM register";
$result = mysqli_query($conn,$query);

if(isset($_REQUEST["submit"]))
{
    $username = $_REQUEST['username'];
    $query = "INSERT INTO blacklist SELECT * FROM register WHERE username ='$username'";
    $data = mysqli_query($conn,$query);

    if($data)
    {
        echo '<script type="text/javascript">
        window.onload = function () { alert("The user was successfully blacklisted");}
        </script>';
    }
    else
    {
        echo '<script type="text/javascript">
        window.onload = function () { alert("Oops! something went wrong");}
        </script>';
    }
}


if(isset($_REQUEST["submit"]))
{
    $username = $_REQUEST['username'];
    $query1 = "DELETE FROM register WHERE username='$username'";
    $data1=mysqli_query($conn,$query1);
}

?>


<!DOCTYPE html>
<html>
    <head>
        <title>
            blacklist employees
        </title>
        <style>
            body{

                margin-top: 0px;
                background: linear-gradient(to left,#8e44ad,#2980b9 )
            
            }
            div{
                
                
                text-align-last: left;
            }
            .topnav {
                background-color: rgb(184, 24, 224);
                overflow: hidden;
              }
              
              .topnav a {
                margin-left: 0px;
                    float: left;
                color: #f2f2f2;
                text-align: center;
                padding: 14px 16px;
                text-decoration: none;
                font-size: 17px;
              }
              
              /* Change the color of links on hover */
              .topnav a:hover {
                background-color: #ddd;
                color: pink;
              }
              
              /* Add a color to the active/current link */
              .topnav a.active {
                background-color: #7604aa;
                color: white;
              }
            .form{
                margin-top: 50px;
                margin-left: 40%;
            }
            input{
                
                width: 250px;
                padding:5px;
            }
            label{
                color:aliceblue;
            }
            h1{
                color:aliceblue;
            }
            * {
                margin: 0px;
                padding: 0;
                font-family: Arial, Helvetica, sans-serif;
            
            }
            
            
            .heading {
                display: flex;
                background-color: #232f3e;
                box-shadow: 0px 1px 2px #232f3e;
            
            }
            h1 {
                color: white;
                font-weight: bold;
                
                background: transparent;
                padding: 7px;
                
            }
            
             table {
                width: 500px;
                border-collapse: collapse;
                overflow: hidden;
                box-shadow: 0 0 20px rgba(0,0,0,0.1);

            }
            th, td {
                padding: 20px;
                background-color: rgba(255,255,255,0.2);
                color: #fff;
            }
            .box{
            
                
                margin-top: 0px;
                margin-bottom: 60%;
                width: 400px;
                padding:20px;
                background:#f9f9f9;
                border:2px solid #333;
                    
            }
            .box label{
                color:#333;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }

            input[type="submit"]{
                width: 10%;
                height: 30px;
                border: 1px solid;
                background: #2691d9;
                
                font-size: 18px;
                color: #e9f4fb;
                font-weight: 700;
                cursor: pointer;
                outline: none;
            }

            input[type="submit"]:hover{
                border-color: #2691d9;
                transition: .5s;
                background: purple;
            }
            
        </style>
    </head>
    <body>
        <div class="topnav">
            <a class="active" href="auhomepage.php">Home</a>
          </div>
        <center>
            <h1>Details of person to be blacklisted</h1> 
            <table>
        <tr>
            <th>empid</th>
            <th>first name</th>
            <th>last name</th>
            <th>email</th>
            <th>contact</th>
            <th>username</th>
            <th>password</th>
        </tr>
        <?php
        while($rows=mysqli_fetch_assoc($result))
        {
        ?>  

        <tr>
            <td><?php echo $rows['username']; ?></td>
            <td><?php echo $rows['firstname']; ?></td>
            <td><?php echo $rows['lastname']; ?></td>
            <td><?php echo $rows['email']; ?></td>
            <td><?php echo $rows['contact']; ?></td>
            <td><?php echo $rows['username']; ?></td>
            <td><?php echo $rows['password']; ?></td>

        <?php
        }
        ?>
       </table>
        </center>
    <div class="form">
       <form >
        
        <center>
        <div class="user-box">
         <label for="name">Username: </label><br>
         <input type="text" id="username" name="username"><br><br>
         
        </div>
        
         <label for="reason">Reason for blacklisting: </label><br>
         <input type="text" id="reason" name="reason"><br><br>
         </div></center>
         <center><input align="center" type="submit" name="submit" id="submit" value="Blacklist"></center>
       </form>
    <br><a href="login.php" style="color:white; font-size:25px; float:center;"><center> Log out </a></center>
    
    </body>
</html>