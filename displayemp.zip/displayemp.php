<?php
$servername = "localhost";
$user = "root";
$password = "";
$dbname = "assist u";

$conn =  mysqli_connect($servername,$user,$password,$dbname);

if($conn)
{
	//echo "Connection Success!";
}
else
{
	echo "Connection failed!".mysqli_connect_error();
}

//error_reporting(0);
session_start();
    $us = $_SESSION['username'];

$query = "SELECT * FROM complaint where username = '$us'";
$result = mysqli_query($conn,$query);

?>

<!DOCTYPE html>
<html>
<head>
	<style>
  body{
  	margin: 0;
	background: linear-gradient(120deg,#2980b9, #8e44ad);
	font-family: sans-serif;
	font-weight: 100;
	height: 100%;
}
    
    .container {
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
}

table {
	width: 800px;
	border-collapse: collapse;
	overflow: hidden;
	box-shadow: 0 0 20px rgba(0,0,0,0.1);
}

th,
td {
	padding: 15px;
	background-color: rgba(255,255,255,0.2);
	color: #fff;
}

th {
	text-align: left;
}

thead {
	th {
		background-color: #55608f;
	}
}

tbody {
	tr {
		&:hover {
			background-color: rgba(255,255,255,0.3);
		}
	}
	td {
		position: relative;
		&:hover {
			&:before {
				content: "";
				position: absolute;
				left: 0;
				right: 0;
				top: -9999px;
				bottom: -9999px;
				background-color: rgba(255,255,255,0.2);
				z-index: -1;
			}
		}
	}
}

.h1 {
  color: white;
  text-align: center;
 }

 .p {
 	color: white;
 }
    </style>
	<body>
		<h1 class="h1">Complaint Record</h1>
		<center>
		<table>
			
			<t>
				<th>Username</th>
				<th>Authorized User</th>
				<th>Complaint against</th>
				<th>Complaint</th>
				<th>Complaint Id</th>
				<th>Re-complaint OR Not</th>
				<th>Previous Id</th>
				<th>Status</th>
			</t>
		<?php
		while($rows=mysqli_fetch_assoc($result))
		{
		?>	

		<tr>
			<td><?php echo $rows['username']; ?></td>
			<td><?php echo $rows['au']; ?></td>
			<td><?php echo $rows['against']; ?></td>
			<td><?php echo $rows['comp']; ?></td>
			<td><?php echo $rows['id']; ?></td>
			<td><?php echo $rows['reornot']; ?></td>
			<td><?php echo $rows['previd']; ?></td>
			<td><?php echo $rows['status']; ?></td>

		<?php
		}
		?>
		</tr>
		</table>
		<p class="p"> Here '0' in 'previous id' means that the complaint is not a re complaint.<br>Values other than 0 shows the complaint id of previously entered complaints if the user has entered the complaint again</p>
		<br>
		 <center>
        <style>
.simple-shadow{
  text-shadow: 1px 2px 2px red;
}
</style>
<p class="simple-shadow"><a href="emphomepage.php" style="color:white; font-size:30px;">HOME</a></center><br>
        <style>
.simple-shadow{
  text-shadow: 1px 2px 2px red;
}
</style><center>
<p class="simple-shadow"><a href="login.php" style="color:white; font-size:25px;">LOG OUT</a></center>
    
<br><br>
    </center>
<br><br>
	</center>
	</body>
</head>
</html>