<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body{
  margin: 0;
  padding: 0;
  background: linear-gradient(120deg,#2980b9, #8e44ad);
  height: 100vh;
  overflow: hidden;
  font-family: Arial, Helvetica, sans-serif;
}

* {box-sizing: border-box;}

.container {
  border-radius: 5px;
  padding: 20px;
}

 .h1 {
  color: white;
  text-align: center;
  font-family: times-new-roman;
  font-size: 40px;
 }

 .box {
  border: 3px solid;
  padding: 7px;
  border-image: linear-gradient(45deg,white,black) 1;
}

.box2 {
  border: 5px solid;
  border-spacing: 4px;
  border-image: linear-gradient(45deg,red,blue) 1;
  font-family: times-new-roman;
  font-size: 40px;
}

table {
  width: 500px;
  border-collapse: collapse;
  overflow: hidden;
  box-shadow: 0 0 20px rgba(0,0,0,0.1);
}

th,
td {
  padding: 15px;
  background-color: rgba(255,255,255,0.2);
  color: #fff;
}
</style>
</head>
<body>
  <div class="box2">
  <h1 class="h1">Home</h1>
</div>
<br>
<h3 style ="color:white;font-family:times-new-roman; font-size:20px;">
<marquee>ASSIST U ---> We Stand By You</marquee>

<center>
  <img src="assist u white.jpg" width="170" height="170">

<div class="container">
<table><th>
<a href="displayallau.php"
    style="color:white; font-size:25px; float:center; text-decoration: none;"> Record of all complaints
</a></th></table>
<table><th>
  <a href="displayreau.php" style="color:white; font-size:25px; float:center;text-decoration: none"> Re-complaints record </a>
</th></table>
<table><th>
  <a href="activitystatus.php" style="color:white; font-size:25px; float:center;text-decoration: none"> Change Activity Status </a>
</th></table>
<table><th>
  <a href="blacklisting.php" style="color:white; font-size:25px; float:center;text-decoration: none"> Blacklist Users </a>
</th></table>
<table><th>
  <a href="whitelist.php" style="color:white; font-size:25px; float:center;text-decoration: none"> Whitelist Users </a>
</th></table>
</div>
    <style>
.simple-shadow{
  text-shadow: 1px 2px 2px red;
}
</style>
<p class="simple-shadow"><a href = "login.php" style="color:white; font-size:25px; float:center;"> LOG OUT </a></p>

</center>
</form>

</body>
</html>